
import { useEffect, useState } from 'react';
import { fetchClinicalCases } from '../service/clinicalCaseService.js';

export default function useClinicalCases() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    async function loadCases() {
      setLoading(true);
      setError('');

      try {
        const data = await fetchClinicalCases({
          signal: controller.signal,
        });

        if (!controller.signal.aborted) {
          setCases(data);
        }
      } catch (err) {
        if (
          err.name !== 'AbortError' &&
          !controller.signal.aborted
        ) {
          setError(err.message || 'Failed to load clinical cases.');
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadCases();

    return () => controller.abort();
  }, []);

  return { cases, loading, error };
}
