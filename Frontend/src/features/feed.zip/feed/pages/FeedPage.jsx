import { useMemo, useRef, useState } from 'react';
import StoryTray from '../components/StoryTray';
import StoryViewer from '../components/StoryViewer';
import ContentCard from '../components/ContentCard';
import PeopleToKnow from '../components/PeopleToKnow';
import './FeedPage.css';
import useFeed from '../hooks/useFeed.js';

const FEED_TABS = ['For you', 'Popular', 'Following'];
const { posts, loading, error, refresh } = useFeed();

function HeroBanner({ onMakeMark }) {
  return (
    <section className="zenve-hero" aria-label="The Zenve Vet community">
      <div className="zenve-hero__copy">
        <p className="zenve-hero__eyebrow">THE ZENVE VET COMMUNITY</p>
        <h1>A world of care. Connected.</h1>
        <p className="zenve-hero__subtitle">
          Meet your peers. Share your practice. Move veterinary care forward.
        </p>
        <button type="button" className="zenve-hero__cta" onClick={onMakeMark}>
          Make your mark <span aria-hidden="true">↗</span>
        </button>
      </div>
      <div className="zenve-hero__art" aria-hidden="true">
        <svg viewBox="0 0 64 64" role="img">
          <path d="M18 8v12c0 9 5 14 14 14s14-5 14-14V8M12 8v7c0 7 3 11 8 13M46 8v7c0 7-3 11-8 13" />
          <path d="M32 34v7c0 9 5 14 14 14 7 0 11-4 11-10 0-4-2-7-6-7s-6 3-6 6" />
          <circle cx="51" cy="38" r="2" />
        </svg>
        <span>BETTER<br />TOGETHER</span>
      </div>
    </section>
  );
}

function CommunityComposer({ currentUser, onRequestLogin }) {
  const [text, setText] = useState('');
  const [selectedType, setSelectedType] = useState('Photo / Post');
  const fileInputRef = useRef(null);
  const avatar = currentUser?.profile_picture || currentUser?.avatar;
  const initial = (currentUser?.full_name || currentUser?.username || ' ')[0]?.toLowerCase();
  const contentTypes = [
    { label: 'Photo / Post', icon: '▧' },
    { label: 'Clinical case', icon: '♧' },
    { label: 'Story', icon: '⊕' },
    { label: 'Short video', icon: '▣' },
    { label: 'AI case assistant', icon: '✧' },
  ];

  function handleAction(label) {
    setSelectedType(label);
    if (!currentUser) {
      onRequestLogin?.();
      return;
    }
    if (label === 'Photo / Post' || label === 'Short video' || label === 'Clinical case') {
      fileInputRef.current?.click();
    }
  }

  return (
    <section className="community-composer" aria-label="Create a community post">
      <div className="community-composer__entry">
        <div className="community-composer__avatar" aria-hidden="true">
          {avatar ? <img src={avatar} alt="" /> : initial}
        </div>
        <textarea
          value={text}
          onChange={(event) => setText(event.target.value)}
          onFocus={() => { if (!currentUser) onRequestLogin?.(); }}
          placeholder="Share a discovery, a case, a little inspiration..."
          aria-label="Write a community post"
          rows={2}
        />
        <button type="button" className="community-composer__expand" aria-label="Expand composer" onClick={() => !currentUser && onRequestLogin?.()}>⌁</button>
      </div>
      <div className="community-composer__tools" aria-label="Writing tools">
        <span className="community-composer__tool-brand">✧ Zynvo AI <b>FREE</b></span>
        {['Write for me', 'Improve', 'Professional', 'Warmer', 'Shorten', 'Remove identifiers'].map((tool) => (
          <button type="button" key={tool} onClick={() => !currentUser && onRequestLogin?.()}>{tool}</button>
        ))}
      </div>
      <div className="community-composer__footer">
        <div className="community-composer__types">
          {contentTypes.map(({ label, icon }) => (
            <button
              type="button"
              key={label}
              className={selectedType === label ? 'is-selected' : ''}
              onClick={() => handleAction(label)}
            >
              <span aria-hidden="true">{icon}</span> {label}
            </button>
          ))}
          <input ref={fileInputRef} type="file" accept="image/*,video/*" hidden onChange={() => { if (!currentUser) onRequestLogin?.(); }} />
        </div>
        <button type="button" className="community-composer__post" onClick={() => onRequestLogin?.()}>
          Post <span aria-hidden="true">↗</span>
        </button>
      </div>
    </section>
  );
}

function ZenveAdvantage() {
  const items = [
    { icon: '◎', title: 'Your own professional page', text: 'A place for your work, your voice, your professional identity.' },
    { icon: '♧', title: 'Meaningful connections', text: 'Discover peers beyond your clinic and your city.' },
    { icon: '♙', title: 'Grow with possibility', text: 'Mentorship, research and innovation pathways.' },
  ];
  return (
    <section className="zenve-advantage">
      <header className="zenve-advantage__header"><h2>THE ZENVE ADVANTAGE</h2><span aria-hidden="true">✧</span></header>
      {items.map((item) => (
        <button type="button" className="zenve-advantage__item" key={item.title}>
          <span className="zenve-advantage__icon" aria-hidden="true">{item.icon}</span>
          <span className="zenve-advantage__copy"><b>{item.title}</b><small>{item.text}</small></span>
          <span className="zenve-advantage__arrow" aria-hidden="true">›</span>
        </button>
      ))}
    </section>
  );
}

export default function FeedPage({ posts = [], peopleToKnow = [], stories = [], currentUser = null, onRequestLogin, onMakeMark }) {
  const [activeStoryIndex, setActiveStoryIndex] = useState(null);
  const [activeTab, setActiveTab] = useState('For you');
  const availableStories = Array.isArray(stories) ? stories : [];
  const availablePosts = Array.isArray(posts) ? posts : [];
  const availablePeople = Array.isArray(peopleToKnow) ? peopleToKnow : [];
  const visiblePosts = useMemo(() => {
    if (activeTab === 'Following') return availablePosts.filter((post) => post.is_following_author === true);
    if (activeTab === 'Popular') return [...availablePosts].sort((a, b) => (b.likes_count || 0) - (a.likes_count || 0));
    return availablePosts;
  }, [activeTab, availablePosts]);

  function openStory(story) {
    const index = availableStories.findIndex((item) => String(item.id ?? item.pk) === String(story.id ?? story.pk));
    if (index >= 0) setActiveStoryIndex(index);
    else if (!currentUser) onRequestLogin?.();
  }

  function nextStory() {
    setActiveStoryIndex((index) => index === null || index >= availableStories.length - 1 ? null : index + 1);
  }

  function previousStory() {
    setActiveStoryIndex((index) => index === null ? null : Math.max(0, index - 1));
  }

  return (
    <main className="feed-page">
      <div className="feed-page__main">
        <HeroBanner onMakeMark={onMakeMark || onRequestLogin} />
        <section className="feed-page__stories-block" aria-label="Community stories">
          <div className="feed-page__section-heading"><h2>Moments from the community</h2><span>STORIES ↗</span></div>
          <StoryTray stories={availableStories} currentUser={currentUser} onOpenStory={openStory} onCreateStory={onRequestLogin} />
        </section>
        <CommunityComposer currentUser={currentUser} onRequestLogin={onRequestLogin} />
        <section className="feed-page__content" aria-label="Community feed">
          <div className="feed-page__tabs" role="tablist" aria-label="Feed filters">
            {FEED_TABS.map((tab) => (
              <button key={tab} type="button" role="tab" aria-selected={activeTab === tab} className={`feed-page__tab ${activeTab === tab ? 'feed-page__tab--active' : ''}`} onClick={() => setActiveTab(tab)}>{tab}</button>
            ))}
            <span className="feed-page__feed-label"><i /> COMMUNITY FEED</span>
          </div>
          {visiblePosts.length ? (
            <div className="feed-page__list">
              {visiblePosts.map((post) => <ContentCard key={post.id ?? post.pk} content={post} type="post" onLike={onRequestLogin} onComment={onRequestLogin} onShare={onRequestLogin} onSave={onRequestLogin} />)}
            </div>
          ) : (
            <div className="feed-page__empty"><h2>No community posts yet</h2><p>Posts will appear here when they are available from the community.</p></div>
          )}
        </section>
      </div>
      <aside className="feed-page__sidebar">
        <PeopleToKnow people={availablePeople} onConnect={onRequestLogin} onSeeAll={onRequestLogin} />
        <ZenveAdvantage />
      </aside>
      {activeStoryIndex !== null && availableStories[activeStoryIndex] && (
        <StoryViewer stories={availableStories} activeIndex={activeStoryIndex} onClose={() => setActiveStoryIndex(null)} onNext={nextStory} onPrevious={previousStory} />
      )}
    </main>
  );
}
