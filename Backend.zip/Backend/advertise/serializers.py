from rest_framework import serializers
from .models import Advertiser


class AdvertiserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Advertiser
        fields = [
            "id",
            "brand_name",
            "contact_email",
            "website",
            "access_key",
            "is_active",
            "created_at",
        ]
        read_only_fields = [
            "id",
            "access_key",
            "is_active",
            "created_at",
        ]


class AdvertiserAccessKeySerializer(serializers.Serializer):
    access_key = serializers.CharField(max_length=64)