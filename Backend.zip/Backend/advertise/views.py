from django.shortcuts import render

# Create your views here.
from rest_framework import status
from rest_framework.decorators import (
    api_view,
    permission_classes,
)
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .models import Advertiser
from .serializers import (
    AdvertiserSerializer,
    AdvertiserAccessKeySerializer,
)


@api_view(["POST"])
@permission_classes([AllowAny])
def create_advertiser(request):
    serializer = AdvertiserSerializer(data=request.data)

    if not serializer.is_valid():
        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST,
        )

    advertiser = serializer.save()

    return Response(
        {
            "message": "Advertiser account created successfully.",
            "advertiser": AdvertiserSerializer(advertiser).data,
        },
        status=status.HTTP_201_CREATED,
    )


@api_view(["POST"])
@permission_classes([AllowAny])
def validate_access_key(request):
    serializer = AdvertiserAccessKeySerializer(data=request.data)

    if not serializer.is_valid():
        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST,
        )

    key = serializer.validated_data["access_key"]

    advertiser = Advertiser.objects.filter(
        access_key=key,
        is_active=True,
    ).first()

    if advertiser is None:
        return Response(
            {"detail": "Invalid access key or inactive advertiser."},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    return Response(
        {
            "message": "Access key validated successfully.",
            "advertiser": AdvertiserSerializer(advertiser).data,
        },
        status=status.HTTP_200_OK,
    )


@api_view(["POST"])
@permission_classes([AllowAny])
def advertiser_dashboard(request):
    serializer = AdvertiserAccessKeySerializer(data=request.data)

    if not serializer.is_valid():
        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST,
        )

    key = serializer.validated_data["access_key"]

    advertiser = Advertiser.objects.filter(
        access_key=key,
        is_active=True,
    ).first()

    if advertiser is None:
        return Response(
            {"detail": "Invalid access key or inactive advertiser."},
            status=status.HTTP_401_UNAUTHORIZED,
        )

    return Response(
        {
            "message": "Dashboard data retrieved successfully.",
            "advertiser": AdvertiserSerializer(advertiser).data,
        },
        status=status.HTTP_200_OK,
    )