from django.urls import path

from .views import (
    create_advertiser,
    validate_access_key,
    advertiser_dashboard,
)

app_name = "advertise"

urlpatterns = [
    path("accounts/", create_advertiser, name="create_advertiser"),
    path("validate-key/", validate_access_key, name="validate_access_key"),
    path("dashboard/", advertiser_dashboard, name="advertiser_dashboard"),
]